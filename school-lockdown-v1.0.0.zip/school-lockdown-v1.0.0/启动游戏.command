#!/bin/bash
# 起一个只监听本机的静态服务器并打开浏览器。关闭本窗口即停止服务。
cd "$(dirname "$0")/网页服务器版" || exit 1
PORT=8123

pick_port() {
  for p in $(seq $PORT $((PORT + 20))); do
    if ! nc -z 127.0.0.1 "$p" >/dev/null 2>&1; then echo "$p"; return; fi
  done
  echo "$PORT"
}
PORT=$(pick_port)

if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT" --bind 127.0.0.1 >/dev/null 2>&1 &
elif command -v python >/dev/null 2>&1; then
  python -m SimpleHTTPServer "$PORT" >/dev/null 2>&1 &
else
  echo "未找到 Python，改用 npx serve ..."
  npx --yes serve -l "$PORT" . >/dev/null 2>&1 &
fi
PID=$!
sleep 1.5
open "http://127.0.0.1:$PORT/"
echo "游戏已打开：http://127.0.0.1:$PORT/  （关闭本窗口即停止服务）"
trap 'kill $PID 2>/dev/null' EXIT INT TERM
wait $PID
