@echo off
chcp 65001 >nul
cd /d "%~dp0网页服务器版"
set PORT=8123
echo 游戏将在浏览器打开：http://127.0.0.1:%PORT%/  （关闭本窗口即停止服务）
start "" "http://127.0.0.1:%PORT%/"
where py >nul 2>nul && (
  py -3 -m http.server %PORT% --bind 127.0.0.1
) || (
  where python >nul 2>nul && (
    python -m http.server %PORT% --bind 127.0.0.1
  ) || (
    echo 未找到 Python，改用 npx serve ...
    npx --yes serve -l %PORT% .
  )
)
